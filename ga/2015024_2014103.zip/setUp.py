class setup(object):
    layer_info = [2,3,1]
    birdsInPlay = 20
    randomBirds = 4
    maxGeneration = 2000
    elites = 5
    mutationRate = 0.20
    tournamentSize = 10
    uniformRate = 0.5
